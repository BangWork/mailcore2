#ifndef MAILCORE_MCHASH_H

#define MAILCORE_MCHASH_H

#ifdef __cplusplus

namespace mailcore {
    
    unsigned int hashCompute(const char * key, unsigned int len);
    
}

#endif

#endif
